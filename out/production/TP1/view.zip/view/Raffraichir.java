package view;

/** Thread de la vue : déclenche des repaint réguliers. */
public class Raffraichir extends Thread {

    public static final int DELAY = 50;

    private final Affichage monAffichage;

    public Raffraichir(Affichage a) {
        monAffichage = a;
        setDaemon(true);
        start();
    }

    @Override
    public void run() {
        while (!isInterrupted()) {
            monAffichage.repaint();
            try {
                sleep(DELAY);
            } catch (InterruptedException e) {
                interrupt();
                break;
            }
        }
    }
}
