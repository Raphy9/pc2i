package model;

/** Thread du modèle : fait descendre la position à intervalle régulier. */
public class Descendre extends Thread {

    public static final int DELAY = 40;

    private final Position maPosition;

    public Descendre(Position p) {
        maPosition = p;
        setDaemon(true);
        start();
    }

    @Override
    public void run() {
        while (!isInterrupted()) {
            maPosition.fall();
            try {
                sleep(DELAY);
            } catch (InterruptedException e) {
                interrupt();
                break;
            }
        }
    }
}
