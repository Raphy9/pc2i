package model;

/**
 * Thread du modèle : incrémente Position.avancement pour faire défiler le parcours.
 * Optionnellement notifie un Parcours pour mise à jour incrémentale.
 */
public class Avancer extends Thread {

    public static final int DELAY = 40; // ms
    private final Position position;
    private final int vitesseX;
    private final Parcours parcours; // may be null

    public Avancer(Position position, int vitesseX, Parcours parcours) {
        this.position = position;
        this.vitesseX = vitesseX;
        this.parcours = parcours;
        setDaemon(true);
        start();
    }

    public Avancer(Position position, int vitesseX) {
        this(position, vitesseX, null);
    }

    @Override
    public void run() {
        while (!isInterrupted()) {
            position.advanceBy(vitesseX);
            if (parcours != null) {
                parcours.onAdvance();
            }
            try {
                sleep(DELAY);
            } catch (InterruptedException e) {
                interrupt();
                break;
            }
        }
    }
}
