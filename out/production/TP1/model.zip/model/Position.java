package model;

/**
 * Modèle représentant la position verticale de l'ovale et son avancement horizontal.
 * Respecte les invariants : HAUTEUR_MIN <= hauteur <= HAUTEUR_MAX - HAUTEUR_OVALE
 */
public class Position {

    public static final int POS_DEPART = 100;
    public static final int IMPULSION = 15; // saut augmente la hauteur

    public static final int HAUTEUR_OVALE = 50;
    public static final int HAUTEUR_MIN = 0;
    public static final int HAUTEUR_MAX = 200;

    public static final int BEFORE = 20;
    public static final int AFTER = 100;

    // vitesse verticale lors de la descente (constante interne)
    private final int vitesse = 2;
    private int hauteur = POS_DEPART;

    // position horizontale d'avancement du modèle (pour le décalage du parcours)
    private int avancement = 0;

    /**
     * Retourne la hauteur actuelle (valeur modèle).
     */
    public synchronized int getPosition() {
        return hauteur;
    }

    /**
     * Effectue un saut : augmente la hauteur en respectant la borne haute utile.
     */
    public synchronized void jump() {
        int hauteurMaxUtile = HAUTEUR_MAX - HAUTEUR_OVALE;
        if (hauteur < hauteurMaxUtile) {
            hauteur += IMPULSION;
            if (hauteur > hauteurMaxUtile) {
                hauteur = hauteurMaxUtile;
            }
        }
    }

    /**
     * Fait descendre l'objet progressivement (appelé par un thread du modèle).
     */
    public synchronized void fall() {
        if (hauteur > HAUTEUR_MIN) {
            hauteur -= vitesse;
            if (hauteur < HAUTEUR_MIN) {
                hauteur = HAUTEUR_MIN;
            }
        }
    }

    /**
     * Retourne l'avancement horizontal (en unités modèle).
     */
    public synchronized int getAvancement() {
        return avancement;
    }

    /**
     * Avance la valeur d'avancement de dx unités (peut être négatif).
     */
    public synchronized void advanceBy(int dx) {
        avancement += dx;
    }
}
